#include<iostream>
using namespace std;
int main(){
    int a,b;
    cin>>a>>b;
    int total = (b/2) + (a-b);
    cout << total << endl;
}