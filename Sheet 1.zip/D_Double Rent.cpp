#include <bits/stdc++.h>
using namespace std;

int main() {
	int x;
	cin>>x;
	
	 x=2*x;
	 
	cout << x << endl;
	return 0;
	

}
