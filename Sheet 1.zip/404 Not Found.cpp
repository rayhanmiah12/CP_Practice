#include <iostream>
using namespace std;

int main() {
    int x;
    cin >> x;

    if (x == 404) {
        cout << "NOT FOUND" << endl;
    } else {
        cout << "FOUND" << endl;
    }

    return 0;
}