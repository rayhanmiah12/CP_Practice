#include <bits/stdc++.h>
using namespace std;

int main() {
	int a,b,ans;
	cin>>a>>b;
	
	ans =10*(a+b)+1;
	cout << ans << endl; 

}
