#include <iostream>
using namespace std;

int main() {
    int X;
    cin >> X;

    if (X >= 12) {
        cout << "Yes" << endl;
    } else {
        cout << "No" << endl;
    }

    return 0;
}



