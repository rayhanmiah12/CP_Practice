#include <iostream>
using namespace std;

int main (){
    int n;
    cin>>n;
    if(n%2==1)
    {
        cout << "YES" << endl;
    }
    else{
        cout << "NO" << endl;
    }
}