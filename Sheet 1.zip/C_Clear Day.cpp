#include <bits/stdc++.h>
using namespace std;

int main() {
	int x,y;
	cin>>x>>y;
    int day = 7-(x+y);
	cout << day << endl;
	    return 0;
	}

