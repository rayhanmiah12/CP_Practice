#include<iostream>
using namespace std;
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        int x;
        cin>>x;
        if(x<=3)
        {
            cout << "BRONZE" << endl;
        }
        else if(x<=6)
        {
            cout << "SILVER" << endl;
        }
        else{
            cout << "GOLD" << endl;
        }
    }
}
